## Packages
framer-motion | Essential for complex 3D animations, layout transitions, and scroll effects
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes safely

## Notes
The design relies heavily on Framer Motion for "live wallpaper" effects.
Glassmorphism requires backdrop-filter support.
