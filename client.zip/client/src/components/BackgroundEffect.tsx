import { motion } from "framer-motion";

export function BackgroundEffect() {
  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden pointer-events-none">
      {/* DARK BASE */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0e2e] via-[#0f1630] to-[#0a0c20]" />

      {/* ANIMATED BLOB 1 - Large flowing shape */}
      <motion.div
        animate={{
          x: [-100, 100, -100],
          y: [-50, 100, -50],
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-[120px]"
        style={{
          background: "radial-gradient(circle, rgba(204, 102, 255, 0.8) 0%, rgba(204, 102, 255, 0) 70%)",
          boxShadow: "0 0 200px 40px rgba(204, 102, 255, 0.25)",
        }}
      />

      {/* ANIMATED BLOB 2 - Secondary smooth shape */}
      <motion.div
        animate={{
          x: [100, -100, 100],
          y: [50, -150, 50],
          scale: [1.1, 0.9, 1.1],
          opacity: [0.25, 0.5, 0.25],
        }}
        transition={{
          duration: 24,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1,
        }}
        className="absolute top-1/3 right-1/4 w-80 h-80 rounded-full blur-[150px]"
        style={{
          background: "radial-gradient(circle, rgba(0, 204, 255, 0.7) 0%, rgba(0, 204, 255, 0) 70%)",
          boxShadow: "0 0 250px 50px rgba(0, 204, 255, 0.2)",
        }}
      />

      {/* ANIMATED BLOB 3 - Accent shape */}
      <motion.div
        animate={{
          x: [0, 80, -80, 0],
          y: [0, -120, 60, 0],
          scale: [0.9, 1.15, 1, 0.9],
          opacity: [0.2, 0.45, 0.3, 0.2],
        }}
        transition={{
          duration: 28,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2,
        }}
        className="absolute bottom-1/4 left-1/3 w-72 h-72 rounded-full blur-[140px]"
        style={{
          background: "radial-gradient(circle, rgba(153, 0, 255, 0.6) 0%, rgba(153, 0, 255, 0) 70%)",
          boxShadow: "0 0 180px 35px rgba(153, 0, 255, 0.15)",
        }}
      />

      {/* VERTICAL LIGHT RAY 1 */}
      <motion.div
        animate={{
          opacity: [0.3, 0.6, 0.3],
          scaleY: [0.9, 1.1, 0.9],
          x: [0, 10, 0],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-0 left-1/3 w-1 h-screen"
        style={{
          background: "linear-gradient(180deg, rgba(204, 102, 255, 0.9) 0%, rgba(204, 102, 255, 0.3) 40%, transparent 100%)",
          filter: "blur(25px)",
          boxShadow: "0 0 80px 15px rgba(204, 102, 255, 0.4), inset 0 0 40px rgba(204, 102, 255, 0.2)",
        }}
      />

      {/* VERTICAL LIGHT RAY 2 */}
      <motion.div
        animate={{
          opacity: [0.25, 0.55, 0.25],
          scaleY: [1, 1.15, 1],
          x: [0, -12, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 0.5,
        }}
        className="absolute top-0 right-1/4 w-1 h-screen"
        style={{
          background: "linear-gradient(180deg, rgba(0, 204, 255, 0.85) 0%, rgba(0, 204, 255, 0.25) 40%, transparent 100%)",
          filter: "blur(30px)",
          boxShadow: "0 0 100px 20px rgba(0, 204, 255, 0.35), inset 0 0 50px rgba(0, 204, 255, 0.15)",
        }}
      />

      {/* GRADIENT MESH EFFECT - Smooth color transitions */}
      <motion.div
        animate={{
          opacity: [0.15, 0.3, 0.15],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(ellipse at 30% 40%, rgba(204, 102, 255, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 70% 60%, rgba(0, 204, 255, 0.12) 0%, transparent 50%),
            radial-gradient(ellipse at 50% 80%, rgba(153, 0, 255, 0.1) 0%, transparent 50%)
          `,
          filter: "blur(60px)",
        }}
      />

      {/* SUBTLE ANIMATED GRADIENT OVERLAY */}
      <motion.div
        animate={{
          opacity: [0.08, 0.15, 0.08],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute inset-0"
        style={{
          background: "linear-gradient(135deg, rgba(204, 102, 255, 0.1) 0%, transparent 50%, rgba(0, 204, 255, 0.1) 100%)",
          filter: "blur(80px)",
        }}
      />

      {/* SOFT EDGE GLOW - Top */}
      <motion.div
        animate={{
          opacity: [0.1, 0.25, 0.1],
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-0 left-0 right-0 h-1/2"
        style={{
          background: "linear-gradient(to bottom, rgba(204, 102, 255, 0.2) 0%, transparent 100%)",
          filter: "blur(80px)",
        }}
      />

      {/* SOFT EDGE GLOW - Bottom */}
      <motion.div
        animate={{
          opacity: [0.08, 0.2, 0.08],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 0.5,
        }}
        className="absolute bottom-0 left-0 right-0 h-1/2"
        style={{
          background: "linear-gradient(to top, rgba(0, 204, 255, 0.15) 0%, transparent 100%)",
          filter: "blur(90px)",
        }}
      />

      {/* ULTRA SUBTLE GRID */}
      <div
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `
            linear-gradient(0deg, transparent 24%, rgba(255, 255, 255, 0.03) 25%, rgba(255, 255, 255, 0.03) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, 0.03) 75%, rgba(255, 255, 255, 0.03) 76%, transparent 77%, transparent),
            linear-gradient(90deg, transparent 24%, rgba(255, 255, 255, 0.03) 25%, rgba(255, 255, 255, 0.03) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, 0.03) 75%, rgba(255, 255, 255, 0.03) 76%, transparent 77%, transparent)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* PREMIUM VIGNETTE */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.6)_100%)]" />

      {/* CORNER ACCENT 1 */}
      <motion.div
        animate={{
          opacity: [0.05, 0.15, 0.05],
          scale: [0.95, 1.05, 0.95],
        }}
        transition={{
          duration: 11,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -top-1/3 -left-1/3 w-2/3 h-2/3 rounded-full"
        style={{
          background: "radial-gradient(circle, rgba(204, 102, 255, 0.2) 0%, transparent 70%)",
          filter: "blur(100px)",
        }}
      />

      {/* CORNER ACCENT 2 */}
      <motion.div
        animate={{
          opacity: [0.04, 0.12, 0.04],
          scale: [1.05, 0.95, 1.05],
        }}
        transition={{
          duration: 13,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1.5,
        }}
        className="absolute -bottom-1/3 -right-1/3 w-2/3 h-2/3 rounded-full"
        style={{
          background: "radial-gradient(circle, rgba(0, 204, 255, 0.15) 0%, transparent 70%)",
          filter: "blur(120px)",
        }}
      />
    </div>
  );
}
