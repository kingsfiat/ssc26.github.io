import { motion } from "framer-motion";
import { TrendingUp, Crown, CheckCircle, Zap } from "lucide-react";

export function SSCPromo() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.3 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  const sceneVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 1 },
    },
  };

  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Scene 1: Power Hook */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-32 text-center"
      >
        <motion.div variants={sceneVariants} className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-secondary/20 to-primary/20 blur-3xl" />
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-6xl md:text-7xl font-bold relative z-10 bg-clip-text text-transparent bg-gradient-to-b from-primary via-secondary to-primary"
          >
            SSC 2026
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="text-xl text-muted-foreground mt-4 relative z-10"
          >
            Not studying more. Studying smarter.
          </motion.p>
        </motion.div>
      </motion.div>

      {/* Scene 2 & 3: The Problem & Solution */}
      <div className="grid md:grid-cols-2 gap-12 mb-32">
        <motion.div
          variants={itemVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="glass-panel p-8 rounded-2xl"
        >
          <div className="text-red-400 text-sm font-semibold mb-4 flex items-center gap-2">
            <Zap className="w-4 h-4 animate-pulse" />
            THE CHALLENGE
          </div>
          <h3 className="text-2xl font-bold mb-6 text-white">
            Confusion. Pressure. Too Many Sources.
          </h3>
          <ul className="space-y-3 text-muted-foreground">
            <li className="flex gap-3">
              <span className="text-primary">✗</span>
              <span>Messy notes scattered everywhere</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary">✗</span>
              <span>Confusion about exam patterns</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary">✗</span>
              <span>Inconsistent preparation strategy</span>
            </li>
          </ul>
        </motion.div>

        <motion.div
          variants={itemVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="glass-panel p-8 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10"
        >
          <div className="text-secondary text-sm font-semibold mb-4 flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            THE SOLUTION
          </div>
          <h3 className="text-2xl font-bold mb-6 text-white">
            One Platform. One Plan. One Goal.
          </h3>
          <ul className="space-y-3 text-muted-foreground">
            <li className="flex gap-3">
              <span className="text-secondary">✓</span>
              <span>Smart classes with real exam patterns</span>
            </li>
            <li className="flex gap-3">
              <span className="text-secondary">✓</span>
              <span>Daily practice & mock tests</span>
            </li>
            <li className="flex gap-3">
              <span className="text-secondary">✓</span>
              <span>Track progress with precision</span>
            </li>
          </ul>
        </motion.div>
      </div>

      {/* Scene 4: Platform Showcase */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-32"
      >
        <h2 className="text-4xl font-bold text-center mb-12 text-white">
          Built for SSC 2026 Rankers
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: <Zap className="w-6 h-6" />,
              title: "Smart Classes",
              desc: "Adaptive learning designed for your pace",
            },
            {
              icon: <TrendingUp className="w-6 h-6" />,
              title: "Real Exam Pattern",
              desc: "Practice exactly like the SSC exam",
            },
            {
              icon: <Crown className="w-6 h-6" />,
              title: "Daily Discipline",
              desc: "Consistent progress tracking and goals",
            },
          ].map((feature, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ y: -10, scale: 1.05 }}
              className="glass-panel p-8 rounded-xl text-center hover:bg-white/10 transition-colors duration-300"
            >
              <div className="flex justify-center mb-4 text-primary">{feature.icon}</div>
              <h3 className="text-lg font-semibold text-white mb-3">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Scene 5: Results */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-32 text-center"
      >
        <motion.div variants={itemVariants} className="glass-panel p-12 rounded-2xl inline-block">
          <div className="mb-6">
            <motion.div
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 100 }}
              className="text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary"
            >
              10,000+
            </motion.div>
          </div>
          <p className="text-lg text-muted-foreground">Students already selected with our system</p>
        </motion.div>
      </motion.div>

      {/* Scene 6: Emotional Push & CTA */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="text-center py-12"
      >
        <motion.h2
          variants={itemVariants}
          className="text-5xl md:text-6xl font-bold mb-6 text-white leading-tight"
        >
          Your Selection<br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
            Starts Here.
          </span>
        </motion.h2>

        <motion.p
          variants={itemVariants}
          className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
        >
          Don't just prepare. Prepare with confidence. Join thousands of students already building
          their success story.
        </motion.p>

        <motion.button
          variants={itemVariants}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' })}
          className="px-10 py-4 rounded-xl bg-gradient-to-r from-primary to-secondary text-white font-semibold shadow-lg shadow-primary/50 hover:shadow-xl hover:shadow-primary/75 transition-all duration-300"
        >
          Join the Batch Now
        </motion.button>
      </motion.div>
    </section>
  );
}
