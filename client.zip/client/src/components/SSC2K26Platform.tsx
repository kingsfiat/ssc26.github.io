import { motion } from "framer-motion";
import { UserCheck, Upload, BarChart3, Zap, Shield, Bell } from "lucide-react";

export function SSC2K26Platform() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  const features = [
    {
      icon: <UserCheck className="w-6 h-6" />,
      title: "Unique Student ID",
      desc: "Your digital identity. Lifetime valid. Auto-generated.",
      badge: "🆔",
    },
    {
      icon: <Upload className="w-6 h-6" />,
      title: "Photo Upload",
      desc: "Admin-approved profile pictures. Secure & safe storage.",
      badge: "📸",
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: "Personal Dashboard",
      desc: "Your profile, batch name, notices & real-time updates.",
      badge: "📊",
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Admin Control",
      desc: "3-4 admins manage all approvals & security. One-click control.",
      badge: "🔐",
    },
    {
      icon: <Bell className="w-6 h-6" />,
      title: "News & Highlights",
      desc: "Glowing breaking news. Important exam updates. Batch announcements.",
      badge: "📢",
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Community Zone",
      desc: "SSC 2026 students only. No fake accounts. Trusted environment.",
      badge: "🧑‍🤝‍🧑",
    },
  ];

  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Header */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-20 text-center"
      >
        <motion.div variants={itemVariants}>
          <div className="text-sm font-semibold text-secondary mb-4 inline-flex items-center gap-2 px-4 py-2 glass-panel rounded-full">
            <Zap className="w-4 h-4" />
            NEXT-GENERATION PLATFORM
          </div>
        </motion.div>

        <motion.h2
          variants={itemVariants}
          className="text-5xl md:text-7xl font-bold mb-6 text-white"
        >
          SSC 2026 (2K26)
          <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
            Your Digital Identity
          </span>
        </motion.h2>

        <motion.p
          variants={itemVariants}
          className="max-w-3xl mx-auto text-lg text-muted-foreground leading-relaxed"
        >
          Not just a website. A lifetime, free digital platform where every student has an identity,
          every update is verified, and the future feels premium. Built for students. Controlled by
          admins. Free for all.
        </motion.p>
      </motion.div>

      {/* Vision Statement */}
      <motion.div
        variants={itemVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="mb-24 text-center"
      >
        <div className="glass-panel p-8 md:p-12 rounded-2xl max-w-3xl mx-auto inline-block w-full">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-2xl md:text-3xl font-bold text-white mb-6 leading-snug"
          >
            "SSC 2026 শুধু একটা পরীক্ষা না…
            <br />
            এটা আমাদের ভবিষ্যৎ।
            <br />
            আর এই প্ল্যাটফর্ম—আমাদের নিজের।"
          </motion.p>
          <p className="text-muted-foreground text-sm md:text-base">
            A free, lifetime digital platform where every student has identity, every update is
            controlled, and the future feels premium.
          </p>
        </div>
      </motion.div>

      {/* Features Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        className="mb-24"
      >
        <h3 className="text-3xl font-bold text-center mb-16 text-white">What Every Student Gets</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ y: -8, scale: 1.02 }}
              className="glass-panel p-8 rounded-xl group hover:bg-white/10 transition-all duration-300"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="text-3xl">{feature.badge}</div>
                <div className="flex-1">
                  <div className="text-primary group-hover:text-secondary transition-colors mb-2">
                    {feature.icon}
                  </div>
                </div>
              </div>
              <h4 className="text-lg font-semibold text-white mb-3">{feature.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Admin System Section */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-24"
      >
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div variants={itemVariants}>
            <div className="glass-panel p-8 rounded-2xl bg-gradient-to-br from-primary/15 to-secondary/15">
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                <Shield className="w-6 h-6 text-primary" />
                Admin Control Panel
              </h3>
              <ul className="space-y-4">
                {[
                  "Approve/block new students",
                  "Student ID management",
                  "Photo approval system",
                  "Important notices upload",
                  "Highlight news & announcements",
                  "Delete fake IDs",
                  "Emergency broadcasts",
                ].map((item, idx) => (
                  <motion.li
                    key={idx}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="flex items-center gap-3 text-muted-foreground hover:text-white transition-colors"
                  >
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    {item}
                  </motion.li>
                ))}
              </ul>
              <p className="text-xs text-muted-foreground mt-6 pt-6 border-t border-white/10">
                3-4 trusted admins have complete control. One-click management.
              </p>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="space-y-6">
            <div className="glass-panel p-6 rounded-xl">
              <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                <Bell className="w-4 h-4 text-secondary" />
                News & Highlights System
              </h4>
              <p className="text-sm text-muted-foreground">
                Breaking news effect with glowing animations. Important SSC updates immediately visible
                to all students. Exam notices, batch announcements, and verified information only.
              </p>
            </div>

            <div className="glass-panel p-6 rounded-xl">
              <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-primary" />
                Community Verification
              </h4>
              <p className="text-sm text-muted-foreground">
                SSC 2026 students only. All students are verified. No fake accounts. No spam. Clean &
                trusted environment. Your peer network you can trust.
              </p>
            </div>

            <div className="glass-panel p-6 rounded-xl">
              <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                <Zap className="w-4 h-4 text-secondary" />
                100% Free, Forever
              </h4>
              <p className="text-sm text-muted-foreground">
                No payment. No subscription. Lifetime access. One official website. Free for all SSC 2026
                students. Your digital identity, owned by you.
              </p>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Community Section */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="text-center"
      >
        <motion.div variants={itemVariants} className="glass-panel p-12 rounded-2xl inline-block">
          <h3 className="text-4xl font-bold text-white mb-4">
            SSC 2026 Students Only Zone
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            Everyone here is from your batch. Everyone is verified. Everyone is working toward the same
            goal.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {["✓ Verified Students", "✓ No Fake Accounts", "✓ Trusted Network", "✓ Lifetime Access"].map(
              (badge, idx) => (
                <motion.span
                  key={idx}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.1 }}
                  className="px-4 py-2 glass-panel rounded-full text-sm font-medium text-primary"
                >
                  {badge}
                </motion.span>
              )
            )}
          </div>
        </motion.div>
      </motion.div>

      {/* CTA */}
      <motion.div
        variants={itemVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="text-center mt-16"
      >
        <button
          onClick={() => document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' })}
          className="px-10 py-4 rounded-xl bg-gradient-to-r from-secondary to-primary text-white font-semibold shadow-lg shadow-secondary/50 hover:shadow-xl hover:shadow-secondary/75 hover:scale-105 transition-all duration-300"
        >
          Get Your Student ID Now
        </button>
        <p className="text-muted-foreground text-sm mt-4">
          Free. Lifetime. One platform. One identity. Your future.
        </p>
      </motion.div>
    </section>
  );
}
