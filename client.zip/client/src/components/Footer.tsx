import { useCreateSubscriber } from "@/hooks/use-subscribers";
import { useState } from "react";
import { Loader2, Send } from "lucide-react";
import { motion } from "framer-motion";

export function Footer() {
  const [email, setEmail] = useState("");
  const { mutate: subscribe, isPending } = useCreateSubscriber();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    subscribe({ email }, {
      onSuccess: () => setEmail("")
    });
  };

  return (
    <footer id="waitlist" className="py-24 relative z-10 border-t border-white/10 bg-black/40">
      <div className="container px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-panel p-12 rounded-3xl relative overflow-hidden"
        >
          {/* Glow backdrop */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-primary/5 blur-3xl -z-10 pointer-events-none" />

          <h2 className="text-3xl md:text-5xl font-bold mb-6 font-display">Join the Future</h2>
          <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto">
            Get exclusive early access to the 3D UI component library and design system documentation.
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto relative z-20">
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isPending}
              required
              className="flex-1 px-6 py-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all"
            />
            <button
              type="submit"
              disabled={isPending}
              className="px-8 py-4 rounded-xl bg-primary text-white font-bold shadow-[0_0_20px_-5px_theme('colors.primary.DEFAULT')] hover:shadow-[0_0_30px_-5px_theme('colors.primary.DEFAULT')] hover:scale-105 active:scale-95 transition-all duration-300 disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2"
            >
              {isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  Access <Send className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <p className="mt-8 text-sm text-muted-foreground/60">
            Limited spots available for the beta release. No spam, ever.
          </p>
        </motion.div>
        
        <div className="mt-16 flex justify-between items-center text-sm text-muted-foreground border-t border-white/5 pt-8">
          <p>© 2024 Future Interface Design. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-primary transition-colors">Twitter</a>
            <a href="#" className="hover:text-primary transition-colors">GitHub</a>
            <a href="#" className="hover:text-primary transition-colors">Discord</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
