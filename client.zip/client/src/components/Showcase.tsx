import { GlassCard } from "./GlassCard";
import { Layers, Move3d, Zap } from "lucide-react";
import { motion } from "framer-motion";

const features = [
  {
    icon: <Move3d className="w-8 h-8 text-primary" />,
    title: "Entrance Animation",
    description: "Elements assemble from light and vertical energy lines, creating a dramatic reveal sequence.",
    glow: "primary" as const
  },
  {
    icon: <Layers className="w-8 h-8 text-secondary" />,
    title: "Idle State",
    description: "Floating UI cards with gentle breathing animations and subtle parallax movement responding to scroll.",
    glow: "secondary" as const
  },
  {
    icon: <Zap className="w-8 h-8 text-accent" />,
    title: "Interaction",
    description: "Responsive 3D tilt effects, intensified edge glows, and magnetic cursor interactions.",
    glow: "none" as const // Using default hover border
  }
];

export function Showcase() {
  return (
    <section id="showcase" className="py-32 relative z-10">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold font-display mb-6"
          >
            Core Animation Concepts
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-muted-foreground"
          >
            Built on advanced physics-based animation engines for fluid, organic motion.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <GlassCard key={i} glow={feature.glow} className="h-full">
              <div className="h-14 w-14 rounded-2xl bg-white/5 flex items-center justify-center mb-6 border border-white/10 shadow-inner">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4 font-display">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
}
