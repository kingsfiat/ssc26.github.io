import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, Cpu, Sparkles } from "lucide-react";

export function Hero() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      <motion.div 
        style={{ y, opacity }}
        className="container px-4 sm:px-6 lg:px-8 relative z-10 text-center"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel text-sm text-secondary font-medium border-secondary/20"
        >
          <Sparkles className="w-4 h-4 animate-pulse" />
          <span>3D Interface Platform</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-8 font-display bg-clip-text text-transparent bg-gradient-to-b from-white via-white/90 to-white/50"
        >
          Turn Ordinary<br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary via-primary to-secondary neon-glow">Websites Into Experiences</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="max-w-3xl mx-auto text-lg text-muted-foreground mb-12 leading-relaxed"
        >
          Create cinematic, interactive 3D interfaces without complex setup. 
          Build immersive digital experiences with smooth animations, volumetric lighting, and modern glassmorphism — designed for designers, developers, and premium brands.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <button 
            onClick={() => document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 rounded-xl bg-gradient-to-r from-secondary to-primary text-foreground font-semibold shadow-lg shadow-secondary/30 hover:shadow-secondary/50 hover:scale-105 transition-all duration-300 flex items-center gap-2"
          >
            Get Early Access <Cpu className="w-4 h-4" />
          </button>
          
          <button 
            onClick={() => document.getElementById('showcase')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 rounded-xl glass-panel text-white font-medium hover:bg-white/10 transition-colors"
          >
            See the Platform
          </button>
        </motion.div>
      </motion.div>


      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-muted-foreground/50"
      >
        <ArrowDown className="w-6 h-6" />
      </motion.div>
    </section>
  );
}
