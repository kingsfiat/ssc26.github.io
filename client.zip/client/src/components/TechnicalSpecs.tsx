import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

const tabs = [
  {
    id: "env",
    label: "Background & Environment",
    content: "A deep, dark void with subtle particle fog. The background uses a complex multi-layered gradient mesh (Midnight Blue to Deep Purple) that shifts slowly over time. Floating geometric primitives add depth perception without distracting from the content."
  },
  {
    id: "lighting",
    label: "Lighting Design",
    content: "Volumetric lighting plays a crucial role. Key lights source from the top-left (Cyber Blue) and rim lights from the bottom-right (Neon Violet). Glass edges catch these lights dynamically as elements tilt, simulating realistic refraction."
  },
  {
    id: "camera",
    label: "Camera Movement",
    content: "The viewport behaves like a floating camera in zero gravity. Scroll events translate to Z-axis movement (dolly in/out) rather than just Y-axis translation, creating a tunnel-like journey through the interface layers."
  }
];

export function TechnicalSpecs() {
  const [activeTab, setActiveTab] = useState(tabs[0].id);

  return (
    <section className="py-32 relative z-10 bg-black/20 backdrop-blur-sm border-y border-white/5">
      <div className="container px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Technical Specifications</h2>
          <p className="text-muted-foreground">The architecture behind the visual experience.</p>
        </div>

        <div className="grid md:grid-cols-[250px_1fr] gap-12">
          {/* Tabs Navigation */}
          <div className="flex flex-col gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "text-left px-6 py-4 rounded-xl transition-all duration-300 relative overflow-hidden group",
                  activeTab === tab.id 
                    ? "text-primary bg-primary/10 border border-primary/20" 
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent"
                )}
              >
                <span className="relative z-10 font-medium">{tab.label}</span>
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="active-tab"
                    className="absolute inset-0 bg-primary/10 z-0"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="min-h-[300px] glass-panel rounded-2xl p-8 relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="prose prose-invert prose-lg"
              >
                <h3 className="text-2xl font-bold mb-6 text-white font-display">
                  {tabs.find(t => t.id === activeTab)?.label}
                </h3>
                <p className="text-gray-300 leading-loose">
                  {tabs.find(t => t.id === activeTab)?.content}
                </p>
                
                {/* Decorative tech elements */}
                <div className="mt-8 pt-8 border-t border-white/10 flex gap-4 text-xs font-mono text-primary/50 uppercase tracking-widest">
                  <span>Render: WebGL 2.0</span>
                  <span>•</span>
                  <span>Physics: Verlet</span>
                  <span>•</span>
                  <span>Lighting: PBR</span>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
