import { motion } from "framer-motion";
import { Users, MessageCircle, Image, Zap, Award, Lock } from "lucide-react";

export function SocialStudyPlatform() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  const socialFeatures = [
    {
      icon: <Image className="w-6 h-6" />,
      title: "Photo & Video Sharing",
      desc: "Share your moments. Admin-approved content only. Like, comment, share.",
      emoji: "📸",
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: "Stories & Updates",
      desc: "24-hour stories. Exam moments. Results. SSC-related memories.",
      emoji: "📖",
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Chat & Messaging",
      desc: "One-to-one chat, group chat, class groups. Secure & monitored.",
      emoji: "💬",
    },
    {
      icon: <Lock className="w-6 h-6" />,
      title: "Subject Groups",
      desc: "Math, English, Science. Discuss, solve doubts. Teachers present.",
      emoji: "👥",
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Teacher Section",
      desc: "Verified teacher profiles. Special badges. Priority doubt replies.",
      emoji: "🎓",
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "News & Updates",
      desc: "Exam updates, board notices, results. Glowing announcements.",
      emoji: "📰",
    },
  ];

  const roles = [
    {
      role: "Students",
      features: ["Unique verified profile", "Share posts & stories", "Join study groups", "Chat with peers"],
      icon: "👨‍🎓",
    },
    {
      role: "Teachers",
      features: ["Verified badge", "Highlighted posts", "Priority in groups", "Direct messaging"],
      icon: "👨‍🏫",
    },
    {
      role: "Admins",
      features: ["Full platform control", "Approve content", "Delete harmful posts", "Post announcements"],
      icon: "🛡️",
    },
  ];

  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Header */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-20 text-center"
      >
        <motion.div variants={itemVariants}>
          <div className="text-sm font-semibold text-secondary mb-4 inline-flex items-center gap-2 px-4 py-2 glass-panel rounded-full">
            <Users className="w-4 h-4" />
            SOCIAL + LEARNING
          </div>
        </motion.div>

        <motion.h2
          variants={itemVariants}
          className="text-5xl md:text-7xl font-bold mb-6 text-white"
        >
          SSC 2026 Social Network
          <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-secondary to-primary">
            Study Together
          </span>
        </motion.h2>

        <motion.p
          variants={itemVariants}
          className="max-w-3xl mx-auto text-lg text-muted-foreground leading-relaxed"
        >
          A private social network and learning platform built only for SSC 2026 students — where
          identity, study, and community come together. Facebook connects the world. SSC 2026 connects
          our future.
        </motion.p>
      </motion.div>

      {/* Core Message */}
      <motion.div
        variants={itemVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="mb-24 text-center"
      >
        <div className="glass-panel p-8 md:p-12 rounded-2xl max-w-2xl mx-auto inline-block w-full">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-2xl md:text-3xl font-bold text-white"
          >
            "এই প্ল্যাটফর্মে আমরা শুধু ছাত্র না,
            <br />
            আমরা একে অপরের সাথী।"
          </motion.p>
          <p className="text-muted-foreground text-sm md:text-base mt-6">
            SSC 2026 শুধু পড়াশোনা না — এটা একটা কমিউনিটি।
          </p>
        </div>
      </motion.div>

      {/* Social Features Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        className="mb-24"
      >
        <h3 className="text-3xl font-bold text-center mb-16 text-white">Platform Features</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {socialFeatures.map((feature, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ y: -8, scale: 1.02 }}
              className="glass-panel p-8 rounded-xl group hover:bg-white/10 transition-all duration-300"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="text-3xl">{feature.emoji}</div>
                <div className="flex-1">
                  <div className="text-secondary group-hover:text-primary transition-colors">
                    {feature.icon}
                  </div>
                </div>
              </div>
              <h4 className="text-lg font-semibold text-white mb-3">{feature.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Roles & Permissions */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-24"
      >
        <h3 className="text-3xl font-bold text-center mb-16 text-white">Everyone Has a Role</h3>
        <div className="grid md:grid-cols-3 gap-6">
          {roles.map((roleItem, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ y: -12 }}
              className="glass-panel p-8 rounded-xl text-center hover:bg-gradient-to-br hover:from-primary/15 hover:to-secondary/15 transition-all duration-300"
            >
              <div className="text-5xl mb-4">{roleItem.icon}</div>
              <h4 className="text-2xl font-bold text-white mb-6">{roleItem.role}</h4>
              <ul className="space-y-3 text-muted-foreground text-sm">
                {roleItem.features.map((feature, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-2 justify-center hover:text-white transition-colors"
                  >
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    {feature}
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* System Details */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="mb-24"
      >
        <div className="grid md:grid-cols-2 gap-8">
          <motion.div variants={itemVariants} className="glass-panel p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
              <Lock className="w-6 h-6 text-secondary" />
              Student-Only Access
            </h3>
            <ul className="space-y-4">
              {[
                "Verified identity required",
                "No fake accounts allowed",
                "Safe community for all",
                "Admin-monitored content",
                "Secure messaging system",
                "Private study groups",
              ].map((item, idx) => (
                <motion.li
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="flex items-center gap-3 text-muted-foreground hover:text-white transition-colors"
                >
                  <span className="w-2 h-2 rounded-full bg-primary" />
                  {item}
                </motion.li>
              ))}
            </ul>
          </motion.div>

          <motion.div variants={itemVariants} className="glass-panel p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
              <Zap className="w-6 h-6 text-primary" />
              Connected Experience
            </h3>
            <ul className="space-y-4">
              {[
                "Share study materials",
                "Solve doubts together",
                "Celebrate successes",
                "Support each other",
                "Build lifelong bonds",
                "One official platform",
              ].map((item, idx) => (
                <motion.li
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="flex items-center gap-3 text-muted-foreground hover:text-white transition-colors"
                >
                  <span className="w-2 h-2 rounded-full bg-secondary" />
                  {item}
                </motion.li>
              ))}
            </ul>
          </motion.div>
        </div>
      </motion.div>

      {/* Vision Statement */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="text-center"
      >
        <motion.div variants={itemVariants} className="glass-panel p-12 rounded-2xl inline-block">
          <h3 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-secondary to-primary mb-4">
            A Private Network for Our Community
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            SSC 2026 students connecting with each other. Sharing knowledge. Building friendships. Growing
            together.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {["Student-Only", "No Outsiders", "Verified Members", "Safe Zone", "Official Platform"].map(
              (badge, idx) => (
                <motion.span
                  key={idx}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.1 }}
                  className="px-4 py-2 glass-panel rounded-full text-sm font-medium text-secondary"
                >
                  {badge}
                </motion.span>
              )
            )}
          </div>
        </motion.div>
      </motion.div>

      {/* CTA */}
      <motion.div
        variants={itemVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="text-center mt-16"
      >
        <button
          onClick={() => document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' })}
          className="px-10 py-4 rounded-xl bg-gradient-to-r from-primary to-secondary text-white font-semibold shadow-lg shadow-primary/50 hover:shadow-xl hover:shadow-primary/75 hover:scale-105 transition-all duration-300"
        >
          Join Our Community Now
        </button>
        <p className="text-muted-foreground text-sm mt-4">
          Study together. Share together. Grow together.
        </p>
      </motion.div>
    </section>
  );
}
