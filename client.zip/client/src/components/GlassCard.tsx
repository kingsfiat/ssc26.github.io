import { motion, HTMLMotionProps } from "framer-motion";
import { cn } from "@/lib/utils";
import React from "react";

interface GlassCardProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  className?: string;
  glow?: "primary" | "secondary" | "none";
}

export const GlassCard = React.forwardRef<HTMLDivElement, GlassCardProps>(
  ({ children, className, glow = "none", ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        whileHover={{ 
          y: -5,
          rotateX: 5,
          rotateY: -5,
          scale: 1.02,
          transition: { duration: 0.3 }
        }}
        className={cn(
          "glass-panel rounded-2xl p-6 md:p-8 relative overflow-hidden group",
          "border border-white/5 hover:border-white/20 transition-colors duration-300",
          glow === "primary" && "hover:shadow-[0_0_30px_-10px_theme('colors.primary.DEFAULT')]",
          glow === "secondary" && "hover:shadow-[0_0_30px_-10px_theme('colors.secondary.DEFAULT')]",
          className
        )}
        style={{ transformStyle: "preserve-3d" }}
        {...props}
      >
        {/* Shine effect */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-tr from-white/5 to-transparent pointer-events-none" />
        
        {/* Content wrapper */}
        <div className="relative z-10" style={{ transform: "translateZ(20px)" }}>
          {children}
        </div>
      </motion.div>
    );
  }
);

GlassCard.displayName = "GlassCard";
