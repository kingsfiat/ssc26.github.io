import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type SubscriberInput } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useCreateSubscriber() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: SubscriberInput) => {
      // Client-side validation using the imported Zod schema
      const validated = api.subscribers.create.input.parse(data);

      const res = await fetch(api.subscribers.create.path, {
        method: api.subscribers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 409) {
          throw new Error("You are already on the list!");
        }
        if (res.status === 400) {
          const errorData = await res.json();
          const parsedError = api.subscribers.create.responses[400].parse(errorData);
          throw new Error(parsedError.message);
        }
        throw new Error("Failed to subscribe");
      }

      return api.subscribers.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      toast({
        title: "Access Granted",
        description: "You have been added to the priority sequence.",
        variant: "default",
        className: "bg-primary text-primary-foreground border-none",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Protocol Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
