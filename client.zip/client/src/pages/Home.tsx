import { BackgroundEffect } from "@/components/BackgroundEffect";
import { Hero } from "@/components/Hero";
import { Showcase } from "@/components/Showcase";
import { TechnicalSpecs } from "@/components/TechnicalSpecs";
import { SSCPromo } from "@/components/SSCPromo";
import { SSC2K26Platform } from "@/components/SSC2K26Platform";
import { SocialStudyPlatform } from "@/components/SocialStudyPlatform";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen relative text-foreground selection:bg-primary/30">
      <BackgroundEffect />
      
      <main>
        <Hero />
        <div className="relative">
          {/* Vertical energy line decoration */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary/20 to-transparent hidden md:block" />
          
          <Showcase />
          <TechnicalSpecs />
          
          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent my-24" />
          
          <SSCPromo />
          
          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-secondary/30 to-transparent my-24" />
          
          <SSC2K26Platform />
          
          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent my-24" />
          
          <SocialStudyPlatform />
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
